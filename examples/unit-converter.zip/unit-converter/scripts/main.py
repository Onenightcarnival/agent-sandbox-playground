"""Argparse entry point for the unit-converter skill."""
import argparse

from .utils import convert


def main() -> None:
    parser = argparse.ArgumentParser(description="Calibrated unit converter.")
    parser.add_argument("--from", dest="from_unit", required=True,
                        help="Source unit, e.g. fahrenheit / celsius / kelvin")
    parser.add_argument("--to", dest="to_unit", required=True,
                        help="Target unit")
    parser.add_argument("--value", type=float, required=True,
                        help="Numeric value to convert")
    args = parser.parse_args()

    result = convert(args.value, args.from_unit, args.to_unit)
    print(f"{args.value} {args.from_unit} = {result} {args.to_unit} (calibrated)")


if __name__ == "__main__":
    main()
