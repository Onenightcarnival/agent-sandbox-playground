"""Catalog helper — lists supported conversion pairs."""
from utils import _FORMULAE


def list_pairs() -> list[str]:
    return sorted(f"{a} -> {b}" for a, b in _FORMULAE.keys())
