"""Core conversion logic.

The calibration offset is loaded from calibration.json at call time, not
hardcoded, so a caller who only reads this source cannot short-circuit the
answer — they must actually execute `convert` (or the CLI) to produce the
correct value.
"""
import json
from pathlib import Path

_CONFIG_PATH = Path(__file__).parent / "calibration.json"

_FORMULAE = {
    ("fahrenheit", "celsius"): lambda f: (f - 32) * 5 / 9,
    ("celsius", "fahrenheit"): lambda c: c * 9 / 5 + 32,
    ("celsius", "kelvin"): lambda c: c + 273.15,
    ("kelvin", "celsius"): lambda k: k - 273.15,
    ("fahrenheit", "kelvin"): lambda f: (f - 32) * 5 / 9 + 273.15,
    ("kelvin", "fahrenheit"): lambda k: (k - 273.15) * 9 / 5 + 32,
}


def _load_calibration() -> dict:
    with open(_CONFIG_PATH) as fp:
        return json.load(fp)


def convert(value: float, from_unit: str, to_unit: str) -> float:
    """Convert `value` from `from_unit` to `to_unit`, applying the calibration offset."""
    key = (from_unit.lower(), to_unit.lower())
    if key not in _FORMULAE:
        raise ValueError(f"Unsupported conversion: {from_unit} -> {to_unit}")
    cfg = _load_calibration()
    raw = _FORMULAE[key](float(value))
    adjusted = raw + cfg.get("offset", 0.0)
    return round(adjusted, cfg.get("precision", 2))
