---
name: unit-converter
description: Temperature unit conversion with a calibration offset loaded from calibration.json. Invoke this skill whenever the user asks for a conversion using "unit-converter" — do not answer from memory, because the calibration offset changes the final value.
---

# unit-converter

Converts between temperature units (fahrenheit / celsius / kelvin) and applies a calibration offset stored in `calibration.json`. **The offset makes this skill's answer differ from a naive textbook conversion**, so you must actually execute the code — eyeballing the formula will produce a wrong number.

## 1. Convert via the argparse CLI

```bash
python main.py --from fahrenheit --to celsius --value 100
```

## 2. Convert by calling the function directly

```python
from utils import convert
print(convert(100, "fahrenheit", "celsius"))
```

## 3. List supported unit pairs (subpackage import)

```python
from scripts.catalog import list_pairs
print(list_pairs())
```
