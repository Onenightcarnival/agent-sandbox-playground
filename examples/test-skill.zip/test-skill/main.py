import argparse
import json
import os

from utils import WEATHER_DB
from scripts.analyzer import analyze


def get_weather(city):
    """Get weather for a city."""
    return WEATHER_DB.get(city, f"No data for {city}")


def convert_temp(value, from_unit, to_unit):
    """Convert between temperature units."""
    # to celsius
    if from_unit == "fahrenheit":
        c = (value - 32) * 5 / 9
    elif from_unit == "kelvin":
        c = value - 273.15
    else:
        c = value
    # from celsius
    if to_unit == "fahrenheit":
        return c * 9 / 5 + 32
    elif to_unit == "kelvin":
        return c + 273.15
    return c


def call_api(endpoint):
    """Call an API using env vars."""
    base_url = os.environ.get("API_BASE_URL", "")
    token = os.environ.get("API_TOKEN", "")
    if not base_url:
        return {"error": "API_BASE_URL not set"}
    if not token:
        return {"error": "API_TOKEN not set"}
    return {
        "url": f"{base_url}{endpoint}",
        "token_preview": f"{token[:4]}...{token[-4:]}" if len(token) > 8 else "****",
        "status": "ok",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Test skill CLI")
    parser.add_argument("--action", required=True, choices=["weather", "convert", "analyze", "api"])
    parser.add_argument("--city", help="City name for weather")
    parser.add_argument("--value", type=float, help="Value for conversion")
    parser.add_argument("--from", dest="from_unit", help="Source unit")
    parser.add_argument("--to", dest="to_unit", help="Target unit")
    parser.add_argument("--text", help="Text for analysis")
    parser.add_argument("--endpoint", help="API endpoint")
    args = parser.parse_args()

    if args.action == "weather":
        print(get_weather(args.city or "Tokyo"))
    elif args.action == "convert":
        result = convert_temp(args.value, args.from_unit, args.to_unit)
        print(f"{args.value} {args.from_unit} = {result:.2f} {args.to_unit}")
    elif args.action == "analyze":
        print(json.dumps(analyze(args.text or "Hello world"), indent=2))
    elif args.action == "api":
        print(json.dumps(call_api(args.endpoint or "/"), indent=2))
