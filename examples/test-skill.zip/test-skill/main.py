from utils import WEATHER_DB

def get_weather(city):
    """Get weather for a city"""
    return WEATHER_DB.get(city, f"No data for {city}")
