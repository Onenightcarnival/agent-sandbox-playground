from scripts.counter import count_words, char_frequency


def analyze(text):
    words = count_words(text)
    freq = char_frequency(text)
    top_chars = sorted(freq.items(), key=lambda x: -x[1])[:5]

    return {
        "word_count": words,
        "char_count": len(text),
        "top_characters": dict(top_chars),
        "avg_word_length": round(sum(len(w) for w in text.split()) / max(words, 1), 1),
    }
