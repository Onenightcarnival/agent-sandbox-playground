WEATHER_DB = {
    "Tokyo": "Sunny, 22C",
    "London": "Cloudy, 15C",
    "New York": "Rainy, 18C",
    "Paris": "Windy, 14C",
}
