---
name: weather-skill
description: Get weather information for any city
---

# Weather Skill

Provides a `get_weather(city)` function that returns weather data for the given city name.
