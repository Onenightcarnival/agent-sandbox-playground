---
name: test-skill
description: Test skill covering function calls, argparse scripts, subpackage imports, and environment variables
---

# Test Skill

A comprehensive test skill for validating the sandbox.

## 1. Function Call

```python
from main import get_weather
print(get_weather("Tokyo"))
```

## 2. Argparse Script

```bash
python main.py --action convert --value 100 --from celsius --to fahrenheit
```

## 3. Subpackage Import

```python
from scripts.analyzer import analyze
print(analyze("Hello world, hello Python"))
```

## 4. Environment Variables

Requires `API_BASE_URL` and `API_TOKEN` to be set.

```bash
python main.py --action api --endpoint /models
```
